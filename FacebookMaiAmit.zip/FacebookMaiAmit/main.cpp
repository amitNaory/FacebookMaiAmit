#include <iostream>
#include "Facebook.h"
using namespace std;

int main() {

	Facebook network;
	try
	{
		network.initial();
		network.start();
		network.freeFriends();
		network.freeFanPages();
		cout << "Thank you for using Facebook!" << endl;
	}
	catch (const exception& e)
	{
		cout << e.what() << endl;
	}
}